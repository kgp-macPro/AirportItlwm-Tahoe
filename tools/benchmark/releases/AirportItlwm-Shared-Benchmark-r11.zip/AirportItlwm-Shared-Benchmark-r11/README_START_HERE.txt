AIRPORTITLWM SHARED BENCHMARK r11 — TOOLS ONLY

Extract this entire folder in Downloads. Paste:

/bin/bash "$HOME/Downloads/AirportItlwm-Shared-Benchmark-r11/SETUP_AirportItlwm_Benchmark.command"

It installs Desktop tools and opens TOOLS/README.md. Differing old files are backed up; TESTS is preserved. No kext, EFI, root patch or network setting is changed. No test starts automatically.

The old beta setup still supplies r7: run this setup afterwards. Read TOOLS/README.md for prerequisites, all candidate commands, wired-server binding and return instructions. Python3.9+, existing iperf3 and Command Line Tools are required.
