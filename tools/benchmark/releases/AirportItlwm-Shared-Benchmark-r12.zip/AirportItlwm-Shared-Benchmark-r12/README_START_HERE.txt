AIRPORTITLWM SHARED BENCHMARK r12 — TOOLS ONLY

Extract this entire folder in Downloads. Paste:

/bin/bash "$HOME/Downloads/AirportItlwm-Shared-Benchmark-r12/SETUP_AirportItlwm_Benchmark.command"

It installs Desktop tools and opens TOOLS/README.md. Differing old files are backed up; TESTS is preserved. No kext, EFI, root patch or network setting is changed. No test starts automatically.

The 3x20 protocol extends UDP loads to 700/800/900 Mbps; the unchanged r11 3x14 runner remains available for historical comparisons. Read TOOLS/README.md for prerequisites, candidate commands, wired-server binding and return instructions. Python 3.9+, existing iperf3 and Command Line Tools are required.
